'use strict';

module.exports = function(Book) {

};
