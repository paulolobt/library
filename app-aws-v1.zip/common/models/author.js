'use strict';

module.exports = function(Author) {

};
